var seconds = 0;
var minutes = 0;
var hours = 0;


function timedCount() {
	
    seconds = seconds + 1;
	if(seconds > 59) {
		seconds = 0;
		minutes += 1;
	}
	if(minutes > 59){
		minutes =0;
		hours += 1;
	}
	
    postMessage(hours + 'h ' + minutes + 'm ' + seconds +'s');
    setTimeout("timedCount()",1000);
	return seconds + minutes*60;
}


timedCount();